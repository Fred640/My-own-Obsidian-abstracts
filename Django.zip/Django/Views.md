Функции или классы которые обрабатывают HTTP запросы и возвращают HTTP ответы

Создание функции представления
```
def index(request)
	return HttpResponse("indexPage")
```
