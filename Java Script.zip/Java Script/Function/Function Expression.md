```
const sum = function(a, b) {
	return a+b
}
```

[[Function Declaration]]
[[Arrow Function]]