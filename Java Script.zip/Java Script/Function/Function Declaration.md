```
fucntion sum (a, b) {
	return(a+b)
}
```

[[Arrow Function]]
[[Function Expression]]
