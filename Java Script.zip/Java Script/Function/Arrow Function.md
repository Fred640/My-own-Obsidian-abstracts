```
const sum = (a, b) => a+b
```

[[Function Declaration]]
[[Function Expression]]
