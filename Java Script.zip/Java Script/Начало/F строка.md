```
console.log(' тебе ${age} лет ')
```