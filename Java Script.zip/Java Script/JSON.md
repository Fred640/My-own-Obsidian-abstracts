это Java Script Object Natation - стадартизированный формат данных в виде js обьекта
свойства не могут быть underfind или функции
нельзя использовать одинарные ковычки или бэктитки а также висячие запятые
 
const myObjToJSON = JSON.stringify(myObj) -  преоброзование js обьекта в json обьект
const myObjBack = JSON.parse(myObjToJSON) - обратная операция

[[Модули]]