
 
let string = "dfnfafr"
string.length - длина строки
 
 
string[0] - символ строки по индексу
 
 
string.at(-1) - символ строки по индексу (можно указывать отрицательный индекс)
 
 
string.toLowerCase()
 - перевод в нижний и верхний регистр
string.toUpperCase()
 
 
string.trim() - обрезать пробелы в начале и в конце строки
string.trimStart()
string.trimStart()
 
 
string.indexOf("f") - найти индекс первого вхождения
 
string.includes("f") - есть ли символ или строка в строке        можно добавить второй аргумент - индекс с которого начать поиск
 
 
string.startsWith("f") - начинаеться ли строка с
string.endsWith("f")
 
 
string.substring(5,8) - обрезание строки по индексу
string.slice(5,8) - можно передать отрицательный индекс
 
 
string.repeat(3) - повторяет строку несколько раз
 
string.replace("f", "q") - что меняем, на что меняем (заменяет лишь первое вхождение)
string.replaceAll("f", "q") - не только перове вхождение
 
string.split("f") - разделить строку на масив по указанному разделителю

[[Методы Number()]]
[[Методы Массива]]