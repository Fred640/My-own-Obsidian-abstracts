npx --v проверка наличия npm
npx create-react-app App_name /home
npm start - запуск

В каталоге publick оставить только html
В каталоге src оставить только App.js и index.js

[[Функционалный компонент]]
